import subprocess
import os

# Configuration
ANDROID_EMULATOR_PATH = "C:/Users/DELL/AppData/Local/Android/Sdk/emulator/emulator.exe"  # Update this to the emulator binary path
ADB_PATH = "C:/Users/DELL/AppData/Local/Android/Sdk/platform-tools/adb.exe"  # Update this to your adb binary path
VIRTUAL_DEVICE_NAME = "Pixel_Fold_API_35.avd"  # Replace with your virtual device name
APK_FILE_PATH = "C:/Users/DELL/Downloads/sample.apk"  # Path to the sample APK file

# Step 1: Launch the Android Emulator
def launch_emulator():
    try:
        print("Starting the Android Emulator...")
        subprocess.Popen([ANDROID_EMULATOR_PATH, "-avd", VIRTUAL_DEVICE_NAME])
    except Exception as e:
        print(f"Failed to start emulator: {e}")

# Step 2: Install APK
def install_apk():
    try:
        print("Waiting for the emulator to boot...")
        subprocess.run([ADB_PATH, "wait-for-device"])
        print("Installing APK...")
        subprocess.run([ADB_PATH, "install", APK_FILE_PATH])
        print("APK installed successfully.")
    except Exception as e:
        print(f"Failed to install APK: {e}")

# Step 3: Retrieve and Log System Information
def get_system_info():
    try:
        print("Retrieving system information...")
        os_version = subprocess.check_output([ADB_PATH, "shell", "getprop ro.build.version.release"]).decode().strip()
        device_model = subprocess.check_output([ADB_PATH, "shell", "getprop ro.product.model"]).decode().strip()
        memory_info = subprocess.check_output([ADB_PATH, "shell", "cat /proc/meminfo | grep MemTotal"]).decode().strip()

        system_info = {
            "OS Version": os_version,
            "Device Model": device_model,
            "Total Memory": memory_info,
        }
        
        print("System Information:")
        for key, value in system_info.items():
            print(f"{key}: {value}")
        return system_info
    except Exception as e:
        print(f"Failed to retrieve system information: {e}")
        return {}

# Main Function
if __name__ == "__main__":
    # Step 1: Launch Emulator
    launch_emulator()

    # Step 2: Install APK
    install_apk()

    # Step 3: Log System Information
    system_info = get_system_info()
    with open("system_info.log", "w") as log_file:
        for key, value in system_info.items():
            log_file.write(f"{key}: {value}\n")
    print("System information logged in system_info.log.")
