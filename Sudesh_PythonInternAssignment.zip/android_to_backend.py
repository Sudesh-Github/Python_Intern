import requests
import json

# Backend server URL (Replace with your actual server address)
SERVER_URL = "http://127.0.0.1:5000/add-app"  # Adjust the endpoint as per your backend API

# Mock data to send (e.g., system information)
mock_data = {
    "app_name": "MockAndroidApp",
    "version": "1.0",
    "description": "This is a mock application for testing connectivity.",
}

def send_data_to_server():
    try:
        print(f"Connecting to server at {SERVER_URL}...")
        # Send a POST request with mock data
        response = requests.post(SERVER_URL, json=mock_data)
        
        # Check if the request was successful
        if response.status_code == 200:
            print("Data sent successfully!")
            print("Server response:")
            print(json.dumps(response.json(), indent=4))
        else:
            print(f"Failed to send data. Status code: {response.status_code}")
            print(response.text)
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    send_data_to_server()
