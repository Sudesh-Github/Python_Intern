from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Configure the database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///apps.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Database model
class AppDetails(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_name = db.Column(db.String(100), nullable=False)
    version = db.Column(db.String(20), nullable=False)
    description = db.Column(db.Text, nullable=False)

# Initialize the database
with app.app_context():
    db.create_all()

# POST /add-app
@app.route('/add-app', methods=['POST'])
def add_app():
    data = request.get_json()
    try:
        new_app = AppDetails(
            app_name=data['app_name'],
            version=data['version'],
            description=data['description']
        )
        db.session.add(new_app)
        db.session.commit()
        return jsonify({"message": "App added successfully!", "id": new_app.id}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# GET /get-app/{id}
@app.route('/get-app/<int:id>', methods=['GET'])
def get_app(id):
    app_details = AppDetails.query.get(id)
    if app_details:
        return jsonify({
            "id": app_details.id,
            "app_name": app_details.app_name,
            "version": app_details.version,
            "description": app_details.description
        }), 200
    return jsonify({"error": "App not found"}), 404

# DELETE /delete-app/{id}
@app.route('/delete-app/<int:id>', methods=['DELETE'])
def delete_app(id):
    app_details = AppDetails.query.get(id)
    if app_details:
        db.session.delete(app_details)
        db.session.commit()
        return jsonify({"message": "App deleted successfully!"}), 200
    return jsonify({"error": "App not found"}), 404

if __name__ == '__main__':
    app.run(debug=True)
